document.querySelector('.btn-rezerwuj').addEventListener('click', function () {
    alert('Rezerwacja dokonana!');
});